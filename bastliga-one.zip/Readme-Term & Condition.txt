Hello,

Thank for downloading Bastliga.

NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 
Paypal account for donation : https://www.paypal.com/paypalme/haniefuhauha

Link to purchase full version and commercial license: 
https://creativemarket.com/MadhalineStudio

Please visit our store for more great fonts : 
https://bifonts.com/vendor/madhaline-studio
https://www.creativefabrica.com/designer/madhaline-studio 
And follow my instagram for update : @hanief_uhauha

If there is a problem, question, or anything about my fonts, please sent an email to madhalien1.3@gmail.com

 How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,


Madhaline Studio 